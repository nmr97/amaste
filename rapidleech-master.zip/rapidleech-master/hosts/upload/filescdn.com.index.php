<?php 
$upload_services[] = 'filescdn.com';
$max_file_size['filescdn.com'] = 2048;
$page_upload['filescdn.com'] = 'filescdn.com.php';  
?>