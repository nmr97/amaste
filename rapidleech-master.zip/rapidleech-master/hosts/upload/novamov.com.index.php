<?
$upload_services[]="novamov.com";
$max_file_size["novamov.com"]=1024;
$page_upload["novamov.com"] = "novamov.com.php";
?>